public class CarClass {

	String carName;
	   int carId;
	   CarClass(String name, int id)
	   {
		this.carName = name;
		this.carId = id;
	   }

}